#ifndef LAXIAN_PARAMETERS_H
#define LAXIAN_PARAMETERS_H




typedef  struct{
    float              length_data;
}LaXianLengthData;




#endif 
