
#!/bin/bash


roslaunch gohi_bringup startup_head_tracker.launch﻿  
sleep 1.0   
echo "head tracking starting success!"





wait
exit 0
