
#!/bin/bash




roslaunch gohi_bringup startup_pxp_pick.launch  
sleep 1.0   
echo "pxp pick starting success!"




wait
exit 0
