
#!/bin/bash



roslaunch gohi_bringup startup_color_roi_save.launch﻿  
sleep 1.0   
echo "measure object starting success!"




wait
exit 0
