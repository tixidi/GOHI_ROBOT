// Auto-generated. Do not edit!

// (in-package gohi_hw_sensor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Puncture {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.Puncture_id = null;
      this.Puncture_cmd = null;
      this.Puncture_data = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('Puncture_id')) {
        this.Puncture_id = initObj.Puncture_id
      }
      else {
        this.Puncture_id = 0;
      }
      if (initObj.hasOwnProperty('Puncture_cmd')) {
        this.Puncture_cmd = initObj.Puncture_cmd
      }
      else {
        this.Puncture_cmd = 0;
      }
      if (initObj.hasOwnProperty('Puncture_data')) {
        this.Puncture_data = initObj.Puncture_data
      }
      else {
        this.Puncture_data = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Puncture
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [Puncture_id]
    bufferOffset = _serializer.uint8(obj.Puncture_id, buffer, bufferOffset);
    // Serialize message field [Puncture_cmd]
    bufferOffset = _serializer.int32(obj.Puncture_cmd, buffer, bufferOffset);
    // Serialize message field [Puncture_data]
    bufferOffset = _serializer.uint32(obj.Puncture_data, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Puncture
    let len;
    let data = new Puncture(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [Puncture_id]
    data.Puncture_id = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [Puncture_cmd]
    data.Puncture_cmd = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [Puncture_data]
    data.Puncture_data = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'gohi_hw_sensor/Puncture';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2ecc29822846eee4df3665b5f0e9747a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 Puncture_id
    int32 Puncture_cmd
    uint32 Puncture_data
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Puncture(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.Puncture_id !== undefined) {
      resolved.Puncture_id = msg.Puncture_id;
    }
    else {
      resolved.Puncture_id = 0
    }

    if (msg.Puncture_cmd !== undefined) {
      resolved.Puncture_cmd = msg.Puncture_cmd;
    }
    else {
      resolved.Puncture_cmd = 0
    }

    if (msg.Puncture_data !== undefined) {
      resolved.Puncture_data = msg.Puncture_data;
    }
    else {
      resolved.Puncture_data = 0
    }

    return resolved;
    }
};

module.exports = Puncture;
