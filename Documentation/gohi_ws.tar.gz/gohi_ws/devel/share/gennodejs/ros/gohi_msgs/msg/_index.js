
"use strict";

let robot_desire_point_config = require('./robot_desire_point_config.js');
let laser_range_config = require('./laser_range_config.js');
let idcard_write_config = require('./idcard_write_config.js');
let idcard_read_config = require('./idcard_read_config.js');
let stair_config = require('./stair_config.js');
let laser_range_config1 = require('./laser_range_config1.js');
let roll_config = require('./roll_config.js');
let robot_state = require('./robot_state.js');
let sick_range = require('./sick_range.js');

module.exports = {
  robot_desire_point_config: robot_desire_point_config,
  laser_range_config: laser_range_config,
  idcard_write_config: idcard_write_config,
  idcard_read_config: idcard_read_config,
  stair_config: stair_config,
  laser_range_config1: laser_range_config1,
  roll_config: roll_config,
  robot_state: robot_state,
  sick_range: sick_range,
};
