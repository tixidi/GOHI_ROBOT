// Auto-generated. Do not edit!

// (in-package gohi_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class roll_config {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.m1_speed = null;
      this.m2_speed = null;
      this.m3_speed = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('m1_speed')) {
        this.m1_speed = initObj.m1_speed
      }
      else {
        this.m1_speed = 0.0;
      }
      if (initObj.hasOwnProperty('m2_speed')) {
        this.m2_speed = initObj.m2_speed
      }
      else {
        this.m2_speed = 0.0;
      }
      if (initObj.hasOwnProperty('m3_speed')) {
        this.m3_speed = initObj.m3_speed
      }
      else {
        this.m3_speed = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type roll_config
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [m1_speed]
    bufferOffset = _serializer.float32(obj.m1_speed, buffer, bufferOffset);
    // Serialize message field [m2_speed]
    bufferOffset = _serializer.float32(obj.m2_speed, buffer, bufferOffset);
    // Serialize message field [m3_speed]
    bufferOffset = _serializer.float32(obj.m3_speed, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type roll_config
    let len;
    let data = new roll_config(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [m1_speed]
    data.m1_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m2_speed]
    data.m2_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m3_speed]
    data.m3_speed = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'gohi_msgs/roll_config';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '58e3c573bfd240a2cab377b54d4abd42';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    float32 m1_speed
    float32 m2_speed
    float32 m3_speed
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new roll_config(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.m1_speed !== undefined) {
      resolved.m1_speed = msg.m1_speed;
    }
    else {
      resolved.m1_speed = 0.0
    }

    if (msg.m2_speed !== undefined) {
      resolved.m2_speed = msg.m2_speed;
    }
    else {
      resolved.m2_speed = 0.0
    }

    if (msg.m3_speed !== undefined) {
      resolved.m3_speed = msg.m3_speed;
    }
    else {
      resolved.m3_speed = 0.0
    }

    return resolved;
    }
};

module.exports = roll_config;
